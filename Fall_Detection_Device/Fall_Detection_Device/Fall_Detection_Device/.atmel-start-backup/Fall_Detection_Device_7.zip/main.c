#include <atmel_start.h>



static uint8_t spiBuffer[16] = {"data"};
static uint8_t dummy = 0xff;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	printf("pass init...");
	while (1) {
		
		SPI_SS_A_set_level(0);
		SPI_0_exchange_byte(dummy);
		SPI_SS_A_set_level(1);
		
		
	}
}
