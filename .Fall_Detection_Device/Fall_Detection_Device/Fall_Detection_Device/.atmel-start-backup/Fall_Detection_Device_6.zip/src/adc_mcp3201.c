/**
 * \file
 *
 * \brief ADC MCP3201 driver.
 *
 (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms,you may use this software and
    any derivatives exclusively with Microchip products.It is your responsibility
    to comply with third party license terms applicable to your use of third party
    software (including open source software) that may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 */

/**
 * \addtogroup doc_driver_adc_mcp3201
 *
 * \section doc_driver_adc_mcp3201_rev Revision History
 * - v0.0.0.1 Initial Commit
 *
 *@{
 */
#include <adc_mcp3201.h>
#include "atmel_start_pins.h"
#include "util/delay.h"

#define POWER_UP_DELAY 300    // us
#define ADCResult_Mask 0x0FFF // 12 bit masking

void MCP3201_select(void);
void MCP3201_deselect(void);

void MCP3201_init()
{

	/* Enable SPI1 */
	PRR2 &= ~(1 << PRSPI1);

	SPCR1 = 1 << SPE                     /* SPI module enable: enabled */
	        | 0 << DORD                  /* Data order: disabled */
	        | 1 << MSTR                  /* Master/Slave select: enabled */
	        | 0 << CPOL                  /* Clock polarity: disabled */
	        | 0 << CPHA                  /* Clock phase: disabled */
	        | 1 << SPIE                  /* SPI interrupt enable: enabled */
	        | (0 << SPR1) | (0 << SPR0); /* SPI Clock rate selection: fosc/4 */

	// SPSR1 = (0 << SPI2X); /* Disable double SPI speed */
}

void MCP3201_cs_low()
{
	MCP3201_select();
}

void MCP3201_cs_high()
{
	MCP3201_deselect();
}

void MCP3201_start_conversion(void)
{
	MCP3201_cs_low();

	_delay_us(POWER_UP_DELAY);
	while (PE2_get_level() == 0) {
	}

	MCP3201_cs_high();
}

void MCP3201_stop_conversion(void)
{
	MCP3201_cs_high();
}

uint16_t MCP3201_get_conversion_result(void)
{
	uint8_t  readData[2];
	uint16_t ADCResult;

	MCP3201_cs_low();

	for (uint8_t i = 0; i < 2; i++) {
		SPDR1 = 0;
		while (!(SPSR1 & (1 << SPIF)))
			;

		readData[i] = SPDR1;
	}

	MCP3201_stop_conversion();

	ADCResult = readData[0];
	ADCResult = (ADCResult << 8) | readData[1];
	ADCResult = (ADCResult >> 1) & ADCResult_Mask;

	return ADCResult;
}
